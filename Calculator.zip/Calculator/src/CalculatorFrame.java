import javax.swing.*;
import java.awt.*;

public class CalculatorFrame extends JFrame {
    public CalculatorFrame(){
      setTitle(("Calculator"));
      CalculatorPanel panel=new CalculatorPanel();
      panel.setLayout(new BorderLayout());
      add(panel);
      pack();





    }
}
