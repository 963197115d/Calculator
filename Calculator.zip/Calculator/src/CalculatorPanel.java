import javax.swing.*;
import java.awt.*;

public class CalculatorPanel extends JPanel {
    public CalculatorPanel(){
    }
}
